import React from 'react';
import logo from './logo.svg';
import './App.css';
import Tempapp from './components/Tempapp';

function App(){
  return(
    <Tempapp />

    
  );
}

export default App;
